import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  streak: integer("streak").default(0),
  totalCardsStudied: integer("total_cards_studied").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const decks = pgTable("decks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  isPublic: boolean("is_public").default(false),
  totalCards: integer("total_cards").default(0),
  accuracy: real("accuracy").default(0),
  lastStudied: timestamp("last_studied"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const cards = pgTable("cards", {
  id: serial("id").primaryKey(),
  deckId: integer("deck_id").notNull(),
  front: text("front").notNull(),
  back: text("back").notNull(),
  difficulty: integer("difficulty").default(0), // 0-4 for spaced repetition
  nextReview: timestamp("next_review").defaultNow(),
  repetitions: integer("repetitions").default(0),
  easeFactor: real("ease_factor").default(2.5),
  interval: integer("interval").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  deckId: integer("deck_id").notNull(),
  cardsStudied: integer("cards_studied").notNull(),
  accuracy: real("accuracy").notNull(),
  duration: integer("duration"), // in seconds
  studyMode: text("study_mode").notNull(), // flashcard, quiz, matching, spaced-rep
  createdAt: timestamp("created_at").defaultNow(),
});

export const cardReviews = pgTable("card_reviews", {
  id: serial("id").primaryKey(),
  cardId: integer("card_id").notNull(),
  userId: integer("user_id").notNull(),
  quality: integer("quality").notNull(), // 0-5 rating
  previousInterval: integer("previous_interval"),
  newInterval: integer("new_interval"),
  reviewedAt: timestamp("reviewed_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertDeckSchema = createInsertSchema(decks).omit({
  id: true,
  totalCards: true,
  accuracy: true,
  lastStudied: true,
  createdAt: true,
});

export const insertCardSchema = createInsertSchema(cards).omit({
  id: true,
  difficulty: true,
  nextReview: true,
  repetitions: true,
  easeFactor: true,
  interval: true,
  createdAt: true,
});

export const insertStudySessionSchema = createInsertSchema(studySessions).omit({
  id: true,
  createdAt: true,
});

export const insertCardReviewSchema = createInsertSchema(cardReviews).omit({
  id: true,
  reviewedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Deck = typeof decks.$inferSelect;
export type InsertDeck = z.infer<typeof insertDeckSchema>;

export type Card = typeof cards.$inferSelect;
export type InsertCard = z.infer<typeof insertCardSchema>;

export type StudySession = typeof studySessions.$inferSelect;
export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;

export type CardReview = typeof cardReviews.$inferSelect;
export type InsertCardReview = z.infer<typeof insertCardReviewSchema>;

// Extended types for UI
export type DeckWithStats = Deck & {
  cards: Card[];
  recentAccuracy?: number;
};

export type CardWithProgress = Card & {
  isNew?: boolean;
  isDue?: boolean;
};

export type StudyStats = {
  cardsToday: number;
  accuracy: number;
  totalDecks: number;
  streak: number;
  weeklyPerformance: Array<{ day: string; accuracy: number }>;
};
