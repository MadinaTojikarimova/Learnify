// Client-side OpenAI utilities and types
export interface FlashcardGenerationRequest {
  text: string;
  deckTitle?: string;
  numberOfCards?: number;
  difficulty?: "easy" | "medium" | "hard";
}

export interface GeneratedFlashcard {
  front: string;
  back: string;
  explanation?: string;
}

export interface TranscriptionResult {
  text: string;
  duration?: number;
  confidence?: number;
}

// This would typically be handled by the backend, but we include types for the frontend
export const DEFAULT_GENERATION_PARAMS = {
  numberOfCards: 10,
  difficulty: "medium" as const,
  includeExplanations: false,
};

export function validateAudioFile(file: File): boolean {
  const validTypes = [
    "audio/mp3",
    "audio/wav", 
    "audio/ogg",
    "audio/m4a",
    "audio/mpeg",
    "audio/webm",
  ];
  
  const maxSize = 25 * 1024 * 1024; // 25MB limit
  
  return validTypes.includes(file.type) && file.size <= maxSize;
}

export function formatDuration(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
}

export function estimateReadingTime(text: string): number {
  // Assuming average reading speed of 200 words per minute
  const words = text.split(/\s+/).length;
  return Math.ceil(words / 200);
}

export function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(word => word.length > 0).length;
}
