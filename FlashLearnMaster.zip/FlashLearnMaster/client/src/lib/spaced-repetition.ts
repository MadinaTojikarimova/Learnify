// Spaced Repetition Algorithm (SM-2) implementation
export interface CardStats {
  repetitions: number;
  easeFactor: number;
  interval: number;
  nextReview: Date;
}

export function calculateNextReview(
  currentStats: CardStats,
  quality: number // 0-5 rating (0-2: fail, 3-5: pass)
): CardStats {
  let { repetitions, easeFactor, interval } = currentStats;

  if (quality >= 3) {
    // Correct response
    if (repetitions === 0) {
      interval = 1;
    } else if (repetitions === 1) {
      interval = 6;
    } else {
      interval = Math.round(interval * easeFactor);
    }
    repetitions++;
  } else {
    // Incorrect response
    repetitions = 0;
    interval = 1;
  }

  // Update ease factor
  easeFactor = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
  
  // Minimum ease factor is 1.3
  if (easeFactor < 1.3) {
    easeFactor = 1.3;
  }

  // Calculate next review date
  const nextReview = new Date();
  nextReview.setDate(nextReview.getDate() + interval);

  return {
    repetitions,
    easeFactor,
    interval,
    nextReview,
  };
}

export function getDifficultyLabel(quality: number): string {
  switch (quality) {
    case 0:
    case 1:
      return "Again";
    case 2:
      return "Hard";
    case 3:
      return "Good";
    case 4:
    case 5:
      return "Easy";
    default:
      return "Unknown";
  }
}

export function getNextIntervalPreview(
  currentStats: CardStats,
  quality: number
): string {
  const nextStats = calculateNextReview(currentStats, quality);
  const days = nextStats.interval;
  
  if (days === 1) {
    return "1 day";
  } else if (days < 30) {
    return `${days} days`;
  } else if (days < 365) {
    const months = Math.round(days / 30);
    return `${months} month${months === 1 ? "" : "s"}`;
  } else {
    const years = Math.round(days / 365);
    return `${years} year${years === 1 ? "" : "s"}`;
  }
}
