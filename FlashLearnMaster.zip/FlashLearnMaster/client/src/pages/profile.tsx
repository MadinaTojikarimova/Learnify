import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import Navigation from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { User, Mail, Calendar, Target, Flame, Trophy, Settings } from "lucide-react";
import type { User as UserType, StudyStats } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const currentUserId = 1;

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({ username: "", firstName: "", lastName: "", email: "" });
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: user } = useQuery<UserType>({
    queryKey: [`/api/user/${currentUserId}`],
  });

  const { data: stats } = useQuery<StudyStats>({
    queryKey: ['/api/users/stats/1'],
  });

  const updateUserMutation = useMutation({
    mutationFn: async (userData: Partial<UserType>) => {
      return await apiRequest("PUT", `/api/user/${currentUserId}`, userData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user/${currentUserId}`] });
      setIsEditing(false);
      toast({
        title: "Success",
        description: "Profile updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEdit = () => {
    if (user) {
      setEditData({
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
      });
      setIsEditing(true);
    }
  };

  const handleSave = () => {
    updateUserMutation.mutate(editData);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditData({ username: "", firstName: "", lastName: "", email: "" });
  };

  const getStreakColor = (streak: number) => {
    if (streak >= 30) return "bg-purple-500";
    if (streak >= 14) return "bg-blue-500";
    if (streak >= 7) return "bg-green-500";
    if (streak >= 3) return "bg-yellow-500";
    return "bg-gray-400";
  };

  const getStreakLabel = (streak: number) => {
    if (streak >= 30) return "Streak Master";
    if (streak >= 14) return "Dedicated Learner";
    if (streak >= 7) return "Week Warrior";
    if (streak >= 3) return "Getting Started";
    return "New Learner";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Profile</h1>
          <p className="text-gray-600">Manage your account and view your learning progress</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Information */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <User className="w-5 h-5" />
                  <span>Personal Information</span>
                </CardTitle>
                {!isEditing && (
                  <Button variant="outline" size="sm" onClick={handleEdit}>
                    <Settings className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                )}
              </CardHeader>
              <CardContent className="space-y-4">
                {isEditing ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                          id="firstName"
                          value={editData.firstName}
                          onChange={(e) => setEditData({ ...editData, firstName: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                          id="lastName"
                          value={editData.lastName}
                          onChange={(e) => setEditData({ ...editData, lastName: e.target.value })}
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        value={editData.username}
                        onChange={(e) => setEditData({ ...editData, username: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={editData.email}
                        onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                      />
                    </div>
                    <div className="flex space-x-2 pt-4">
                      <Button onClick={handleSave} disabled={updateUserMutation.isPending}>
                        {updateUserMutation.isPending ? "Saving..." : "Save Changes"}
                      </Button>
                      <Button variant="outline" onClick={handleCancel}>
                        Cancel
                      </Button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
                        <span className="text-white text-xl font-bold">
                          {user?.firstName?.charAt(0)}{user?.lastName?.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold">{user?.firstName} {user?.lastName}</h3>
                        <p className="text-gray-600">@{user?.username}</p>
                      </div>
                    </div>
                    <Separator />
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <Mail className="w-4 h-4 text-gray-400" />
                        <span>{user?.email}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span>Member since {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'Unknown'}</span>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Learning Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5" />
                  <span>Learning Statistics</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{stats?.totalDecks || 0}</div>
                    <div className="text-sm text-gray-600">Total Decks</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{user?.totalCardsStudied || 0}</div>
                    <div className="text-sm text-gray-600">Cards Studied</div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Overall Accuracy</span>
                    <span className="text-sm text-gray-600">{stats?.accuracy || 0}%</span>
                  </div>
                  <Progress value={stats?.accuracy || 0} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Streak Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Flame className="w-5 h-5" />
                  <span>Study Streak</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-4">
                  <div className="text-4xl font-bold text-orange-500 mb-2">{stats?.streak || 0}</div>
                  <div className="text-sm text-gray-600">days in a row</div>
                </div>
                <Badge className={`${getStreakColor(stats?.streak || 0)} text-white`}>
                  {getStreakLabel(stats?.streak || 0)}
                </Badge>
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5" />
                  <span>Achievements</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                  <div className="text-2xl">🎯</div>
                  <div>
                    <div className="font-medium">First Steps</div>
                    <div className="text-sm text-gray-600">Created your first deck</div>
                  </div>
                </div>
                
                {(stats?.streak || 0) >= 7 && (
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl">🔥</div>
                    <div>
                      <div className="font-medium">Week Warrior</div>
                      <div className="text-sm text-gray-600">7-day study streak</div>
                    </div>
                  </div>
                )}
                
                {(stats?.accuracy || 0) >= 80 && (
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl">🏆</div>
                    <div>
                      <div className="font-medium">Accuracy Expert</div>
                      <div className="text-sm text-gray-600">80%+ accuracy rate</div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  Export Study Data
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Download App
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Share Profile
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}