import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import Navigation from "@/components/navigation";
import Flashcard from "@/components/flashcard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Clock, BookOpen, Target, Trophy, ArrowLeft, Shuffle, Timer, Zap } from "lucide-react";
import type { Card as FlashCard, Deck, StudySession } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type StudyMode = "flashcards" | "quiz" | "speed" | "mixed";

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  cardId: number;
}

export default function Study() {
  const [, params] = useRoute("/study/:deckId");
  const [, setLocation] = useLocation();
  const [studyMode, setStudyMode] = useState<StudyMode>("flashcards");
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [studySession, setStudySession] = useState<StudySession | null>(null);
  const [sessionStartTime] = useState(Date.now());
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [totalAnswered, setTotalAnswered] = useState(0);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);
  const [timerActive, setTimerActive] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deckId = params?.deckId ? parseInt(params.deckId) : null;

  const { data: deck } = useQuery<Deck>({
    queryKey: [`/api/decks/${deckId}`],
    enabled: !!deckId,
  });

  const { data: cards } = useQuery<FlashCard[]>({
    queryKey: ['/api/cards/deck', deckId],
    enabled: !!deckId,
  });

  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      return await apiRequest("POST", "/api/study/session", sessionData);
    },
    onSuccess: (session) => {
      setStudySession(session);
    },
  });

  const recordAnswerMutation = useMutation({
    mutationFn: async (data: { cardId: number; quality: number }) => {
      return await apiRequest("POST", "/api/study/answer", data);
    },
  });

  // Generate quiz questions from cards
  const generateQuizQuestions = (cards: FlashCard[]): QuizQuestion[] => {
    return cards.map((card) => {
      const otherCards = cards.filter(c => c.id !== card.id);
      const wrongAnswers = otherCards
        .sort(() => Math.random() - 0.5)
        .slice(0, 3)
        .map(c => c.back);
      
      const options = [card.back, ...wrongAnswers].sort(() => Math.random() - 0.5);
      const correctAnswer = options.indexOf(card.back);

      return {
        question: card.front,
        options,
        correctAnswer,
        cardId: card.id,
      };
    });
  };

  // Timer effect for speed mode
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timerActive && timeLeft > 0 && studyMode === "speed") {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && studyMode === "speed") {
      handleTimeUp();
    }
    return () => clearInterval(interval);
  }, [timerActive, timeLeft, studyMode]);

  useEffect(() => {
    if (deckId && !studySession) {
      createSessionMutation.mutate({
        deckId,
        userId: 1,
        studyMode: studyMode,
        accuracy: 0,
        cardsStudied: 0,
      });
    }
  }, [deckId, studySession, studyMode]);

  useEffect(() => {
    if (cards && studyMode === "quiz") {
      setQuizQuestions(generateQuizQuestions(cards));
    }
  }, [cards, studyMode]);

  const handleTimeUp = () => {
    setTimerActive(false);
    handleAnswer(1); // Mark as incorrect
  };

  const handleAnswer = async (quality: number) => {
    if (!cards || !cards[currentCardIndex]) return;

    const isCorrect = quality >= 3;
    if (isCorrect) {
      setCorrectAnswers(prev => prev + 1);
    }
    setTotalAnswered(prev => prev + 1);

    await recordAnswerMutation.mutateAsync({
      cardId: cards[currentCardIndex].id,
      quality,
    });

    // Reset timer for speed mode
    if (studyMode === "speed") {
      setTimeLeft(30);
      setTimerActive(true);
    }

    if (currentCardIndex < cards.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setShowAnswer(false);
    } else {
      // Session complete
      const accuracy = Math.round(((correctAnswers + (isCorrect ? 1 : 0)) / (totalAnswered + 1)) * 100);
      const duration = Math.round((Date.now() - sessionStartTime) / 1000);
      
      toast({
        title: "Study Session Complete!",
        description: `You answered ${correctAnswers + (isCorrect ? 1 : 0)}/${totalAnswered + 1} cards correctly (${accuracy}%)`,
      });
      
      setLocation("/dashboard");
    }
  };

  const handleQuizAnswer = (answerIndex: number) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(answerIndex);
    setShowAnswer(true);
    
    const currentQuestion = quizQuestions[currentCardIndex];
    const isCorrect = answerIndex === currentQuestion.correctAnswer;
    
    setTimeout(() => {
      handleAnswer(isCorrect ? 4 : 1);
    }, 1500);
  };

  const shuffleCards = () => {
    if (cards) {
      const shuffled = [...cards].sort(() => Math.random() - 0.5);
      queryClient.setQueryData(['/api/cards/deck', deckId], shuffled);
      setCurrentCardIndex(0);
      if (studyMode === "quiz") {
        setQuizQuestions(generateQuizQuestions(shuffled));
      }
    }
  };

  const startSpeedMode = () => {
    setStudyMode("speed");
    setTimeLeft(30);
    setTimerActive(true);
  };

  if (!deckId || !deck || !cards) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <div className="text-lg text-gray-600">Loading study session...</div>
          </div>
        </div>
      </div>
    );
  }

  const currentCard = cards[currentCardIndex];
  const currentQuestion = quizQuestions[currentCardIndex];
  const progress = ((currentCardIndex + 1) / cards.length) * 100;
  const accuracy = totalAnswered > 0 ? Math.round((correctAnswers / totalAnswered) * 100) : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={() => setLocation("/dashboard")}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Dashboard</span>
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{deck.title}</h1>
              <p className="text-gray-600">Study Session - {studyMode.charAt(0).toUpperCase() + studyMode.slice(1)} Mode</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {studyMode === "speed" && (
              <Badge variant={timeLeft <= 10 ? "destructive" : "outline"} className="flex items-center space-x-1">
                <Timer className="w-3 h-3" />
                <span>{timeLeft}s</span>
              </Badge>
            )}
            <Badge variant="outline" className="flex items-center space-x-1">
              <Target className="w-3 h-3" />
              <span>{accuracy}% accuracy</span>
            </Badge>
            <Badge variant="outline" className="flex items-center space-x-1">
              <BookOpen className="w-3 h-3" />
              <span>{currentCardIndex + 1} of {cards.length}</span>
            </Badge>
          </div>
        </div>

        {/* Study Mode Selector */}
        <div className="flex flex-wrap gap-2 mb-6">
          <Button
            variant={studyMode === "flashcards" ? "default" : "outline"}
            onClick={() => setStudyMode("flashcards")}
            className="flex items-center space-x-2"
          >
            <BookOpen className="w-4 h-4" />
            <span>Flashcards</span>
          </Button>
          <Button
            variant={studyMode === "quiz" ? "default" : "outline"}
            onClick={() => setStudyMode("quiz")}
            className="flex items-center space-x-2"
          >
            <Target className="w-4 h-4" />
            <span>Quiz</span>
          </Button>
          <Button
            variant={studyMode === "speed" ? "default" : "outline"}
            onClick={startSpeedMode}
            className="flex items-center space-x-2"
          >
            <Zap className="w-4 h-4" />
            <span>Speed Mode</span>
          </Button>
          <Button
            variant="outline"
            onClick={shuffleCards}
            className="flex items-center space-x-2"
          >
            <Shuffle className="w-4 h-4" />
            <span>Shuffle</span>
          </Button>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Progress</span>
            <span className="text-sm text-gray-500">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Study Area */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Study Content */}
          <div className="lg:col-span-3">
            {studyMode === "flashcards" || studyMode === "speed" ? (
              currentCard && (
                <Flashcard card={currentCard} onAnswer={handleAnswer} />
              )
            ) : studyMode === "quiz" && currentQuestion ? (
              <Card className="w-full">
                <CardHeader>
                  <CardTitle className="text-xl">Quiz Question</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-lg font-medium">{currentQuestion.question}</div>
                  
                  <div className="space-y-3">
                    {currentQuestion.options.map((option, index) => (
                      <Button
                        key={index}
                        variant={
                          selectedAnswer === null 
                            ? "outline" 
                            : index === currentQuestion.correctAnswer
                              ? "default"
                              : selectedAnswer === index
                                ? "destructive"
                                : "outline"
                        }
                        className="w-full text-left justify-start h-auto p-4"
                        onClick={() => handleQuizAnswer(index)}
                        disabled={selectedAnswer !== null}
                      >
                        <span className="mr-3 font-bold">{String.fromCharCode(65 + index)}.</span>
                        {option}
                      </Button>
                    ))}
                  </div>
                  
                  {showAnswer && (
                    <div className={`p-4 rounded-lg ${
                      selectedAnswer === currentQuestion.correctAnswer 
                        ? "bg-green-50 border border-green-200" 
                        : "bg-red-50 border border-red-200"
                    }`}>
                      <div className="font-medium">
                        {selectedAnswer === currentQuestion.correctAnswer ? "Correct! ✓" : "Incorrect ✗"}
                      </div>
                      {selectedAnswer !== currentQuestion.correctAnswer && (
                        <div className="text-sm mt-1">
                          The correct answer was: {currentQuestion.options[currentQuestion.correctAnswer]}
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : null}
          </div>

          {/* Study Stats */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Session Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Cards Studied</span>
                  <span className="font-medium">{totalAnswered}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Correct</span>
                  <span className="font-medium text-green-600">{correctAnswers}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Accuracy</span>
                  <span className="font-medium">{accuracy}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Remaining</span>
                  <span className="font-medium">{cards.length - currentCardIndex - 1}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center space-x-2">
                  <Trophy className="w-4 h-4" />
                  <span>Study Tips</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm text-gray-600">
                  • {studyMode === "flashcards" ? "Take your time to read each card carefully" :
                     studyMode === "quiz" ? "Read all options before selecting" :
                     "Answer quickly but accurately"}
                </div>
                <div className="text-sm text-gray-600">
                  • Use honest difficulty ratings
                </div>
                <div className="text-sm text-gray-600">
                  • Regular practice improves retention
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}