import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Flashcard from "@/components/flashcard";
import DeckCard from "@/components/deck-card";
import StudyCalendar from "@/components/study-calendar";
import PerformanceChart from "@/components/performance-chart";
import FloatingActionButton from "@/components/floating-action-button";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Leaf, Target, Folder, Flame, LayersIcon, Upload, Plus } from "lucide-react";
import type { DeckWithStats, StudyStats, Card as FlashCard } from "@shared/schema";
import { useState } from "react";

const currentUserId = 1; // Default user for demo

export default function Dashboard() {
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [studyProgress, setStudyProgress] = useState(32);

  const { data: stats } = useQuery<StudyStats>({
    queryKey: ['/api/users/stats/1'],
  });

  const { data: decks } = useQuery<DeckWithStats[]>({
    queryKey: ['/api/decks/1'],
  });

  const { data: dueCards } = useQuery<FlashCard[]>({
    queryKey: decks?.[0] ? ['/api/cards/due', decks[0].id] : null,
    enabled: !!decks?.[0],
  });

  const currentCard = dueCards?.[currentCardIndex];

  const handleCardAnswer = (quality: number) => {
    // Update progress
    setStudyProgress(prev => Math.min(prev + 4, 100));
    
    // Move to next card
    if (dueCards && currentCardIndex < dueCards.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
    } else {
      setCurrentCardIndex(0);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {getGreeting()}, Madina! 👋
              </h1>
              <p className="text-gray-600">Ready to continue your learning journey?</p>
            </div>
            <div className="flex items-center space-x-3 mt-4 md:mt-0">
              <Button variant="outline" className="flex items-center space-x-2">
                <Upload className="w-4 h-4" />
                <span>Upload Lecture</span>
              </Button>
              <Button className="flex items-center space-x-2">
                <Plus className="w-4 h-4" />
                <span>New Deck</span>
              </Button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Cards Studied Today</p>
                    <p className="text-2xl font-bold text-gray-900">{stats?.cardsToday || 0}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <LayersIcon className="w-6 h-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Accuracy Rate</p>
                    <p className="text-2xl font-bold text-success">{stats?.accuracy || 0}%</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Target className="w-6 h-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Total Decks</p>
                    <p className="text-2xl font-bold text-gray-900">{stats?.totalDecks || 0}</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Folder className="w-6 h-6 text-secondary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Study Streak</p>
                    <p className="text-2xl font-bold text-warning">{stats?.streak || 0} days</p>
                  </div>
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <Flame className="w-6 h-6 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Study Section */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Quick Study</h2>
                  <Button variant="ghost" size="sm">View All</Button>
                </div>
                
                {currentCard ? (
                  <>
                    <Flashcard 
                      card={currentCard}
                      onAnswer={handleCardAnswer}
                    />

                    {/* Progress Bar */}
                    <div className="mt-6">
                      <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                        <span>Progress</span>
                        <span>{Math.floor((studyProgress / 100) * (dueCards?.length || 25))} of {dueCards?.length || 25} cards</span>
                      </div>
                      <Progress value={studyProgress} className="h-2" />
                    </div>
                  </>
                ) : (
                  <div className="text-center py-12">
                    <Leaf className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No cards due for review!</p>
                    <p className="text-sm text-gray-500">Great job staying on top of your studies.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Deck Management */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">My Decks</h2>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      <LayersIcon className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {decks?.map((deck) => (
                    <DeckCard key={deck.id} deck={deck} />
                  ))}
                  
                  <Card className="border-2 border-dashed border-gray-300 hover:border-gray-400 transition-colors cursor-pointer">
                    <CardContent className="p-8 flex flex-col items-center justify-center text-center">
                      <Plus className="w-8 h-8 text-gray-400 mb-2" />
                      <p className="text-gray-600 font-medium">Create New Deck</p>
                      <p className="text-sm text-gray-500">Add cards manually or upload content</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* AI Upload Feature */}
            <div className="gradient-primary rounded-xl p-6 text-white">
              <div className="flex items-center space-x-3 mb-4">
                <Leaf className="w-8 h-8" />
                <div>
                  <h3 className="font-semibold">AI Flashcard Generator</h3>
                  <p className="text-sm opacity-90">Turn lectures into flashcards</p>
                </div>
              </div>
              <div className="space-y-3">
                <Button 
                  variant="ghost" 
                  className="w-full bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-sm border border-white border-opacity-30 text-white"
                >
                  <span className="mr-2">🎤</span>
                  Record Audio
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-sm border border-white border-opacity-30 text-white"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Upload File
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-sm border border-white border-opacity-30 text-white"
                >
                  <span className="mr-2">📋</span>
                  Paste Text
                </Button>
              </div>
            </div>

            <StudyCalendar />
            <PerformanceChart weeklyPerformance={stats?.weeklyPerformance || []} />

            {/* Study Modes */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Study Modes</h3>
                <div className="space-y-3">
                  <Button variant="ghost" className="w-full justify-start h-auto p-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                      <span className="text-primary">🔄</span>
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Flashcards</p>
                      <p className="text-sm text-gray-600">Classic card review</p>
                    </div>
                  </Button>
                  
                  <Button variant="ghost" className="w-full justify-start h-auto p-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                      <span className="text-success">❓</span>
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Quiz Mode</p>
                      <p className="text-sm text-gray-600">Test your knowledge</p>
                    </div>
                  </Button>
                  
                  <Button variant="ghost" className="w-full justify-start h-auto p-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                      <span className="text-secondary">🧩</span>
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Matching</p>
                      <p className="text-sm text-gray-600">Match terms and definitions</p>
                    </div>
                  </Button>
                  
                  <Button variant="ghost" className="w-full justify-start h-auto p-3">
                    <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center mr-3">
                      <span className="text-warning">🧠</span>
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Spaced Rep</p>
                      <p className="text-sm text-gray-600">Optimized learning</p>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <FloatingActionButton />
    </div>
  );
}
