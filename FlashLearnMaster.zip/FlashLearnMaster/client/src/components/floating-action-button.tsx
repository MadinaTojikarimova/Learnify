import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus, X, Mic, Upload, Edit } from "lucide-react";
import AIUploadDialog from "./ai-upload-dialog";

export default function FloatingActionButton() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAIDialogOpen, setIsAIDialogOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleAISuccess = (flashcards: any[]) => {
    console.log("Generated flashcards:", flashcards);
    // Handle the generated flashcards - could create a new deck, etc.
  };

  return (
    <>
      <div className="fixed bottom-6 right-6 z-50">
        <div className="relative">
          {/* Main FAB */}
          <Button
            onClick={toggleMenu}
            className="w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
          >
            {isMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Plus className="w-6 h-6" />
            )}
          </Button>

          {/* Menu Items */}
          <div 
            className={`absolute bottom-16 right-0 space-y-3 transition-all duration-200 ${
              isMenuOpen 
                ? "opacity-100 translate-y-0 pointer-events-auto" 
                : "opacity-0 translate-y-4 pointer-events-none"
            }`}
          >
            <Button
              variant="outline"
              size="sm"
              className="w-12 h-12 rounded-full shadow-lg bg-white hover:bg-gray-50"
              onClick={() => {
                setIsAIDialogOpen(true);
                setIsMenuOpen(false);
              }}
            >
              <Mic className="w-5 h-5" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              className="w-12 h-12 rounded-full shadow-lg bg-white hover:bg-gray-50"
              onClick={() => {
                setIsAIDialogOpen(true);
                setIsMenuOpen(false);
              }}
            >
              <Upload className="w-5 h-5" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              className="w-12 h-12 rounded-full shadow-lg bg-white hover:bg-gray-50"
            >
              <Edit className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      <AIUploadDialog
        isOpen={isAIDialogOpen}
        onClose={() => setIsAIDialogOpen(false)}
        onSuccess={handleAISuccess}
      />
    </>
  );
}
