import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Edit, Share, Trash2, Play } from "lucide-react";
import { Link } from "wouter";
import type { DeckWithStats } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DeckCardProps {
  deck: DeckWithStats;
  viewMode?: "grid" | "list";
}

export default function DeckCard({ deck, viewMode = "grid" }: DeckCardProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteDeckMutation = useMutation({
    mutationFn: async (deckId: number) => {
      await apiRequest("DELETE", `/api/decks/${deckId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/decks/1'] });
      toast({
        title: "Success",
        description: "Deck deleted successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete deck. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this deck? This action cannot be undone.")) {
      deleteDeckMutation.mutate(deck.id);
    }
  };

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 80) return "text-success";
    if (accuracy >= 60) return "text-warning";
    return "text-destructive";
  };

  const getAccuracyDotColor = (accuracy: number) => {
    if (accuracy >= 80) return "bg-success";
    if (accuracy >= 60) return "bg-warning";
    return "bg-destructive";
  };

  if (viewMode === "list") {
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-semibold text-gray-900">{deck.title}</h3>
                  <p className="text-sm text-gray-600">{deck.description}</p>
                </div>
                <div className="flex items-center space-x-1">
                  <Button variant="ghost" size="sm" onClick={handleDelete}>
                    <Trash2 className="w-4 h-4 text-gray-400" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Edit className="w-4 h-4 text-gray-400" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Share className="w-4 h-4 text-gray-400" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span>{deck.totalCards} cards</span>
                  <div className="flex items-center space-x-1">
                    <div className={`w-2 h-2 rounded-full ${getAccuracyDotColor(deck.recentAccuracy || 0)}`}></div>
                    <span className={getAccuracyColor(deck.recentAccuracy || 0)}>
                      {Math.round(deck.recentAccuracy || 0)}%
                    </span>
                  </div>
                </div>
                <Link href={`/study/${deck.id}`}>
                  <Button size="sm">
                    <Play className="w-4 h-4 mr-1" />
                    Study
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-1">{deck.title}</h3>
            <p className="text-sm text-gray-600 line-clamp-2">{deck.description}</p>
          </div>
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="sm" onClick={handleDelete}>
              <Trash2 className="w-4 h-4 text-gray-400" />
            </Button>
            <Button variant="ghost" size="sm">
              <Edit className="w-4 h-4 text-gray-400" />
            </Button>
            <Button variant="ghost" size="sm">
              <Share className="w-4 h-4 text-gray-400" />
            </Button>
          </div>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">{deck.totalCards} cards</span>
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <div className={`w-2 h-2 rounded-full ${getAccuracyDotColor(deck.recentAccuracy || 0)}`}></div>
              <span className={getAccuracyColor(deck.recentAccuracy || 0)}>
                {Math.round(deck.recentAccuracy || 0)}%
              </span>
            </div>
            <Link href={`/study/${deck.id}`}>
              <Button size="sm">Study</Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
