import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface PerformanceChartProps {
  weeklyPerformance: Array<{ day: string; accuracy: number }>;
}

export default function PerformanceChart({ weeklyPerformance }: PerformanceChartProps) {
  // Default data if none provided
  const defaultData = [
    { day: "Mon", accuracy: 85 },
    { day: "Tue", accuracy: 92 },
    { day: "Wed", accuracy: 78 },
    { day: "Thu", accuracy: 96 },
    { day: "Fri", accuracy: 89 },
    { day: "Sat", accuracy: 94 },
    { day: "Sun", accuracy: 87 },
  ];

  const data = weeklyPerformance.length > 0 ? weeklyPerformance : defaultData;

  const getProgressColor = (accuracy: number) => {
    if (accuracy >= 90) return "bg-success";
    if (accuracy >= 75) return "bg-primary";
    if (accuracy >= 60) return "bg-warning";
    return "bg-destructive";
  };

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg">Weekly Performance</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {data.map((item, index) => (
          <div key={index} className="flex items-center justify-between">
            <span className="text-sm text-gray-600 w-8">{item.day}</span>
            <div className="flex-1 mx-3">
              <Progress 
                value={item.accuracy} 
                className={`h-2 ${getProgressColor(item.accuracy)}`}
              />
            </div>
            <span className="text-sm font-medium w-8 text-right">{item.accuracy}%</span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
