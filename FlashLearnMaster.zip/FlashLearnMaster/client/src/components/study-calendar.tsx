import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function StudyCalendar() {
  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();
  const currentDate = today.getDate();

  // Get first day of month and number of days
  const firstDay = new Date(currentYear, currentMonth, 1).getDay();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  // Sample study data - in a real app this would come from the backend
  const studyDays = new Set([4, 5, 6, 7, 8, 9]); // Days with study activity

  const dayNames = ["S", "M", "T", "W", "T", "F", "S"];

  const renderCalendarDays = () => {
    const days = [];

    // Add day headers
    dayNames.forEach((day, index) => (
      days.push(
        <div key={`header-${index}`} className="p-2 text-center text-xs font-medium text-gray-500">
          {day}
        </div>
      )
    ));

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(
        <div key={`empty-${i}`} className="p-2"></div>
      );
    }

    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const isToday = day === currentDate;
      const hasStudied = studyDays.has(day);
      const isPast = day < currentDate;

      let cellClass = "p-2 text-center text-xs rounded cursor-pointer transition-colors ";
      
      if (isToday) {
        cellClass += "bg-primary text-white font-bold ";
      } else if (hasStudied) {
        cellClass += "bg-success text-white ";
      } else if (isPast) {
        cellClass += "text-gray-400 ";
      } else {
        cellClass += "text-gray-700 hover:bg-gray-100 ";
      }

      days.push(
        <div key={day} className={cellClass}>
          {day}
        </div>
      );
    }

    return days;
  };

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg">Study Calendar</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-7 gap-1 text-center">
          {renderCalendarDays()}
        </div>
        
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-success rounded"></div>
            <span className="text-gray-600">Studied</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded"></div>
            <span className="text-gray-600">Today</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
