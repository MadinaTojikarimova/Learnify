import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Clock, Check } from "lucide-react";
import type { Card as FlashCard } from "@shared/schema";

interface FlashcardProps {
  card: FlashCard;
  onAnswer: (quality: number) => void;
}

export default function Flashcard({ card, onAnswer }: FlashcardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  const handleCardClick = () => {
    if (!isFlipped) {
      setIsFlipped(true);
    }
  };

  const handleAnswer = (quality: number) => {
    onAnswer(quality);
    setIsFlipped(false);
  };

  return (
    <div className="space-y-6">
      {/* Flashcard */}
      <div className="card-flip">
        <div 
          className={`card-inner relative w-full h-64 cursor-pointer ${isFlipped ? 'flipped' : ''}`}
          onClick={handleCardClick}
        >
          {/* Front */}
          <Card className="card-front absolute inset-0 gradient-primary text-white">
            <CardContent className="h-full flex items-center justify-center p-8">
              <div className="text-center">
                <h3 className="text-2xl font-semibold mb-4">{card.front}</h3>
                {!isFlipped && (
                  <p className="text-sm opacity-75">Click to reveal answer</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Back */}
          <Card className="card-back absolute inset-0 bg-white border-2 border-gray-200">
            <CardContent className="h-full flex items-center justify-center p-8">
              <div className="text-center">
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">{card.back}</h3>
                <p className="text-sm text-gray-600">How well did you know this?</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Answer Buttons */}
      {isFlipped && (
        <div className="flex items-center justify-center space-x-4 animate-slide-up">
          <Button
            onClick={() => handleAnswer(1)}
            className="flex-1 bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            <X className="w-4 h-4 mr-2" />
            Hard
          </Button>
          <Button
            onClick={() => handleAnswer(3)}
            className="flex-1 bg-warning text-warning-foreground hover:bg-warning/90"
          >
            <Clock className="w-4 h-4 mr-2" />
            Good
          </Button>
          <Button
            onClick={() => handleAnswer(5)}
            className="flex-1 bg-success text-success-foreground hover:bg-success/90"
          >
            <Check className="w-4 h-4 mr-2" />
            Easy
          </Button>
        </div>
      )}
    </div>
  );
}
