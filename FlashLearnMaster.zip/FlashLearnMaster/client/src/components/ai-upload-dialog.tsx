import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Upload, Mic, FileText, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AIUploadDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (flashcards: any[]) => void;
}

export default function AIUploadDialog({ isOpen, onClose, onSuccess }: AIUploadDialogProps) {
  const [text, setText] = useState("");
  const [deckTitle, setDeckTitle] = useState("");
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const generateFlashcardsMutation = useMutation({
    mutationFn: async ({ text, deckTitle }: { text: string; deckTitle: string }) => {
      const response = await apiRequest("POST", "/api/ai/generate-flashcards", {
        text,
        deckTitle,
      });
      return response.json();
    },
    onSuccess: (flashcards) => {
      onSuccess(flashcards);
      onClose();
      toast({
        title: "Success!",
        description: `Generated ${flashcards.length} flashcards from your content.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate flashcards. Please try again.",
        variant: "destructive",
      });
    },
  });

  const transcribeAudioMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("audio", file);
      
      const response = await fetch("/api/ai/transcribe", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to transcribe audio");
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      setText(result.text);
      toast({
        title: "Audio transcribed!",
        description: "Your audio has been converted to text. Review and generate flashcards.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to transcribe audio. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerateFlashcards = () => {
    if (!text.trim()) {
      toast({
        title: "Error",
        description: "Please provide some text content.",
        variant: "destructive",
      });
      return;
    }

    generateFlashcardsMutation.mutate({ text, deckTitle });
  };

  const handleAudioUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAudioFile(file);
      transcribeAudioMutation.mutate(file);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: "audio/wav" });
        const file = new File([blob], "recording.wav", { type: "audio/wav" });
        setAudioFile(file);
        transcribeAudioMutation.mutate(file);
        stream.getTracks().forEach(track => track.stop());
      };

      setIsRecording(true);
      mediaRecorder.start();

      // Stop recording after 60 seconds max
      setTimeout(() => {
        if (mediaRecorder.state === "recording") {
          mediaRecorder.stop();
          setIsRecording(false);
        }
      }, 60000);

      // Add click listener to stop recording
      const stopRecording = () => {
        if (mediaRecorder.state === "recording") {
          mediaRecorder.stop();
          setIsRecording(false);
        }
      };

      // Store the stop function so we can call it from the button
      (window as any).stopRecording = stopRecording;
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to access microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if ((window as any).stopRecording) {
      (window as any).stopRecording();
    }
    setIsRecording(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>AI Flashcard Generator</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="text" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="text">Text</TabsTrigger>
            <TabsTrigger value="audio">Audio</TabsTrigger>
            <TabsTrigger value="file">File</TabsTrigger>
          </TabsList>

          <TabsContent value="text" className="space-y-4">
            <div>
              <Label htmlFor="deck-title">Deck Title (Optional)</Label>
              <Input
                id="deck-title"
                placeholder="Enter a title for your deck"
                value={deckTitle}
                onChange={(e) => setDeckTitle(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="text-content">Text Content</Label>
              <Textarea
                id="text-content"
                placeholder="Paste your lecture notes, article, or any text content here..."
                value={text}
                onChange={(e) => setText(e.target.value)}
                rows={8}
              />
            </div>
          </TabsContent>

          <TabsContent value="audio" className="space-y-4">
            <div>
              <Label htmlFor="deck-title-audio">Deck Title (Optional)</Label>
              <Input
                id="deck-title-audio"
                placeholder="Enter a title for your deck"
                value={deckTitle}
                onChange={(e) => setDeckTitle(e.target.value)}
              />
            </div>
            <div className="space-y-4">
              <div>
                <Label>Record Audio</Label>
                <div className="flex items-center space-x-4 mt-2">
                  {!isRecording ? (
                    <Button onClick={startRecording} disabled={transcribeAudioMutation.isPending}>
                      <Mic className="w-4 h-4 mr-2" />
                      Start Recording
                    </Button>
                  ) : (
                    <Button onClick={stopRecording} variant="destructive">
                      <span className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></span>
                      Stop Recording
                    </Button>
                  )}
                </div>
              </div>
              
              <div>
                <Label htmlFor="audio-upload">Or Upload Audio File</Label>
                <Input
                  id="audio-upload"
                  type="file"
                  accept="audio/*"
                  onChange={handleAudioUpload}
                  disabled={transcribeAudioMutation.isPending}
                  className="mt-2"
                />
              </div>

              {transcribeAudioMutation.isPending && (
                <div className="flex items-center space-x-2 text-gray-600">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Transcribing audio...</span>
                </div>
              )}

              {text && (
                <div>
                  <Label>Transcribed Text</Label>
                  <Textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    rows={6}
                    className="mt-2"
                  />
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="file" className="space-y-4">
            <div>
              <Label htmlFor="deck-title-file">Deck Title (Optional)</Label>
              <Input
                id="deck-title-file"
                placeholder="Enter a title for your deck"
                value={deckTitle}
                onChange={(e) => setDeckTitle(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="file-upload">Upload File</Label>
              <Input
                id="file-upload"
                type="file"
                accept=".txt,.md,.doc,.docx,.pdf"
                className="mt-2"
              />
              <p className="text-sm text-gray-600 mt-1">
                Supported formats: TXT, MD, DOC, DOCX, PDF
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end space-x-2 pt-4">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleGenerateFlashcards}
            disabled={generateFlashcardsMutation.isPending || !text.trim()}
          >
            {generateFlashcardsMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 mr-2" />
                Generate Flashcards
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
