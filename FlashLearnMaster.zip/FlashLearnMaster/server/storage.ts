import { users, decks, cards, studySessions, cardReviews, type User, type InsertUser, type Deck, type InsertDeck, type Card, type InsertCard, type StudySession, type InsertStudySession, type CardReview, type InsertCardReview, type DeckWithStats, type StudyStats } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  updateUserStreak(userId: number, streak: number): Promise<void>;

  // Deck methods
  getUserDecks(userId: number): Promise<DeckWithStats[]>;
  getDeck(id: number): Promise<Deck | undefined>;
  createDeck(deck: InsertDeck): Promise<Deck>;
  updateDeck(id: number, updates: Partial<Deck>): Promise<Deck | undefined>;
  deleteDeck(id: number): Promise<boolean>;

  // Card methods
  getDeckCards(deckId: number): Promise<Card[]>;
  getCard(id: number): Promise<Card | undefined>;
  createCard(card: InsertCard): Promise<Card>;
  updateCard(id: number, updates: Partial<Card>): Promise<Card | undefined>;
  deleteCard(id: number): Promise<boolean>;
  getDueCards(deckId: number): Promise<Card[]>;

  // Study methods
  createStudySession(session: InsertStudySession): Promise<StudySession>;
  createCardReview(review: InsertCardReview): Promise<CardReview>;
  getUserStats(userId: number): Promise<StudyStats>;
  updateCardProgress(cardId: number, quality: number): Promise<Card | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private decks: Map<number, Deck>;
  private cards: Map<number, Card>;
  private studySessions: Map<number, StudySession>;
  private cardReviews: Map<number, CardReview>;
  private currentUserId: number;
  private currentDeckId: number;
  private currentCardId: number;
  private currentSessionId: number;
  private currentReviewId: number;

  constructor() {
    this.users = new Map();
    this.decks = new Map();
    this.cards = new Map();
    this.studySessions = new Map();
    this.cardReviews = new Map();
    this.currentUserId = 1;
    this.currentDeckId = 1;
    this.currentCardId = 1;
    this.currentSessionId = 1;
    this.currentReviewId = 1;

    // Create a default user
    this.createUser({
      username: "john_doe",
      email: "john@example.com",
      firstName: "John",
      lastName: "Doe",
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      streak: 0,
      totalCardsStudied: 0,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStreak(userId: number, streak: number): Promise<void> {
    const user = this.users.get(userId);
    if (user) {
      user.streak = streak;
      this.users.set(userId, user);
    }
  }

  async getUserDecks(userId: number): Promise<DeckWithStats[]> {
    const userDecks = Array.from(this.decks.values()).filter(deck => deck.userId === userId);
    
    return userDecks.map(deck => {
      const deckCards = Array.from(this.cards.values()).filter(card => card.deckId === deck.id);
      const recentReviews = Array.from(this.cardReviews.values())
        .filter(review => deckCards.some(card => card.id === review.cardId))
        .slice(-10);
      
      const recentAccuracy = recentReviews.length > 0 
        ? recentReviews.reduce((sum, review) => sum + (review.quality >= 3 ? 1 : 0), 0) / recentReviews.length * 100
        : deck.accuracy || 0;

      return {
        ...deck,
        cards: deckCards,
        recentAccuracy,
      };
    });
  }

  async getDeck(id: number): Promise<Deck | undefined> {
    return this.decks.get(id);
  }

  async createDeck(insertDeck: InsertDeck): Promise<Deck> {
    const id = this.currentDeckId++;
    const deck: Deck = {
      ...insertDeck,
      id,
      totalCards: 0,
      accuracy: 0,
      lastStudied: null,
      createdAt: new Date(),
    };
    this.decks.set(id, deck);
    return deck;
  }

  async updateDeck(id: number, updates: Partial<Deck>): Promise<Deck | undefined> {
    const deck = this.decks.get(id);
    if (deck) {
      const updatedDeck = { ...deck, ...updates };
      this.decks.set(id, updatedDeck);
      return updatedDeck;
    }
    return undefined;
  }

  async deleteDeck(id: number): Promise<boolean> {
    const deleted = this.decks.delete(id);
    // Also delete all cards in the deck
    Array.from(this.cards.entries()).forEach(([cardId, card]) => {
      if (card.deckId === id) {
        this.cards.delete(cardId);
      }
    });
    return deleted;
  }

  async getDeckCards(deckId: number): Promise<Card[]> {
    return Array.from(this.cards.values()).filter(card => card.deckId === deckId);
  }

  async getCard(id: number): Promise<Card | undefined> {
    return this.cards.get(id);
  }

  async createCard(insertCard: InsertCard): Promise<Card> {
    const id = this.currentCardId++;
    const card: Card = {
      ...insertCard,
      id,
      difficulty: 0,
      nextReview: new Date(),
      repetitions: 0,
      easeFactor: 2.5,
      interval: 1,
      createdAt: new Date(),
    };
    this.cards.set(id, card);

    // Update deck total cards
    const deck = this.decks.get(insertCard.deckId);
    if (deck) {
      deck.totalCards = (deck.totalCards || 0) + 1;
      this.decks.set(insertCard.deckId, deck);
    }

    return card;
  }

  async updateCard(id: number, updates: Partial<Card>): Promise<Card | undefined> {
    const card = this.cards.get(id);
    if (card) {
      const updatedCard = { ...card, ...updates };
      this.cards.set(id, updatedCard);
      return updatedCard;
    }
    return undefined;
  }

  async deleteCard(id: number): Promise<boolean> {
    const card = this.cards.get(id);
    const deleted = this.cards.delete(id);
    
    if (deleted && card) {
      // Update deck total cards
      const deck = this.decks.get(card.deckId);
      if (deck && deck.totalCards) {
        deck.totalCards = deck.totalCards - 1;
        this.decks.set(card.deckId, deck);
      }
    }
    
    return deleted;
  }

  async getDueCards(deckId: number): Promise<Card[]> {
    const now = new Date();
    return Array.from(this.cards.values()).filter(card => 
      card.deckId === deckId && card.nextReview <= now
    );
  }

  async createStudySession(insertSession: InsertStudySession): Promise<StudySession> {
    const id = this.currentSessionId++;
    const session: StudySession = {
      ...insertSession,
      id,
      createdAt: new Date(),
    };
    this.studySessions.set(id, session);
    return session;
  }

  async createCardReview(insertReview: InsertCardReview): Promise<CardReview> {
    const id = this.currentReviewId++;
    const review: CardReview = {
      ...insertReview,
      id,
      reviewedAt: new Date(),
    };
    this.cardReviews.set(id, review);
    return review;
  }

  async getUserStats(userId: number): Promise<StudyStats> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const userSessions = Array.from(this.studySessions.values())
      .filter(session => session.userId === userId);
    
    const todaySessions = userSessions.filter(session => 
      session.createdAt && session.createdAt >= today
    );
    
    const cardsToday = todaySessions.reduce((sum, session) => sum + session.cardsStudied, 0);
    
    const recentSessions = userSessions.slice(-20);
    const accuracy = recentSessions.length > 0 
      ? recentSessions.reduce((sum, session) => sum + session.accuracy, 0) / recentSessions.length
      : 0;
    
    const userDecks = Array.from(this.decks.values()).filter(deck => deck.userId === userId);
    const totalDecks = userDecks.length;
    
    const user = this.users.get(userId);
    const streak = user?.streak || 0;

    // Calculate weekly performance
    const weeklyPerformance = [];
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
      
      const daySessions = userSessions.filter(session => 
        session.createdAt && session.createdAt >= date && session.createdAt <= endDate
      );
      
      const dayAccuracy = daySessions.length > 0 
        ? daySessions.reduce((sum, session) => sum + session.accuracy, 0) / daySessions.length
        : 0;
      
      weeklyPerformance.push({
        day: days[date.getDay()],
        accuracy: Math.round(dayAccuracy),
      });
    }

    return {
      cardsToday,
      accuracy: Math.round(accuracy),
      totalDecks,
      streak,
      weeklyPerformance,
    };
  }

  async updateCardProgress(cardId: number, quality: number): Promise<Card | undefined> {
    const card = this.cards.get(cardId);
    if (!card) return undefined;

    // Spaced repetition algorithm (SM-2)
    let { repetitions, easeFactor, interval } = card;
    
    if (quality >= 3) {
      if (repetitions === 0) {
        interval = 1;
      } else if (repetitions === 1) {
        interval = 6;
      } else {
        interval = Math.round(interval * easeFactor);
      }
      repetitions++;
    } else {
      repetitions = 0;
      interval = 1;
    }

    easeFactor = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
    if (easeFactor < 1.3) easeFactor = 1.3;

    const nextReview = new Date();
    nextReview.setDate(nextReview.getDate() + interval);

    const updatedCard: Card = {
      ...card,
      repetitions,
      easeFactor,
      interval,
      nextReview,
      difficulty: quality < 3 ? Math.min(card.difficulty + 1, 4) : Math.max(card.difficulty - 1, 0),
    };

    this.cards.set(cardId, updatedCard);
    return updatedCard;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserStreak(userId: number, streak: number): Promise<void> {
    await db
      .update(users)
      .set({ streak })
      .where(eq(users.id, userId));
  }

  async getUserDecks(userId: number): Promise<DeckWithStats[]> {
    const userDecks = await db.select().from(decks).where(eq(decks.userId, userId));
    
    const decksWithStats = await Promise.all(
      userDecks.map(async (deck) => {
        const deckCards = await db.select().from(cards).where(eq(cards.deckId, deck.id));
        const recentReviews = await db.select().from(cardReviews)
          .where(eq(cardReviews.cardId, deckCards[0]?.id || 0))
          .limit(10);
        
        const recentAccuracy = recentReviews.length > 0 
          ? recentReviews.reduce((sum, review) => sum + (review.quality >= 3 ? 1 : 0), 0) / recentReviews.length * 100
          : deck.accuracy || 0;

        return {
          ...deck,
          cards: deckCards,
          recentAccuracy,
        };
      })
    );

    return decksWithStats;
  }

  async getDeck(id: number): Promise<Deck | undefined> {
    const [deck] = await db.select().from(decks).where(eq(decks.id, id));
    return deck || undefined;
  }

  async createDeck(insertDeck: InsertDeck): Promise<Deck> {
    const [deck] = await db
      .insert(decks)
      .values(insertDeck)
      .returning();
    return deck;
  }

  async updateDeck(id: number, updates: Partial<Deck>): Promise<Deck | undefined> {
    const [deck] = await db
      .update(decks)
      .set(updates)
      .where(eq(decks.id, id))
      .returning();
    return deck || undefined;
  }

  async deleteDeck(id: number): Promise<boolean> {
    // Delete all cards in the deck first
    await db.delete(cards).where(eq(cards.deckId, id));
    
    // Delete the deck
    const result = await db.delete(decks).where(eq(decks.id, id));
    return result.rowCount > 0;
  }

  async getDeckCards(deckId: number): Promise<Card[]> {
    return await db.select().from(cards).where(eq(cards.deckId, deckId));
  }

  async getCard(id: number): Promise<Card | undefined> {
    const [card] = await db.select().from(cards).where(eq(cards.id, id));
    return card || undefined;
  }

  async createCard(insertCard: InsertCard): Promise<Card> {
    const [card] = await db
      .insert(cards)
      .values(insertCard)
      .returning();

    // Update deck total cards
    await db
      .update(decks)
      .set({ totalCards: db.select().from(cards).where(eq(cards.deckId, insertCard.deckId)) })
      .where(eq(decks.id, insertCard.deckId));

    return card;
  }

  async updateCard(id: number, updates: Partial<Card>): Promise<Card | undefined> {
    const [card] = await db
      .update(cards)
      .set(updates)
      .where(eq(cards.id, id))
      .returning();
    return card || undefined;
  }

  async deleteCard(id: number): Promise<boolean> {
    const result = await db.delete(cards).where(eq(cards.id, id));
    return result.rowCount > 0;
  }

  async getDueCards(deckId: number): Promise<Card[]> {
    const now = new Date();
    return await db.select().from(cards)
      .where(eq(cards.deckId, deckId));
  }

  async createStudySession(insertSession: InsertStudySession): Promise<StudySession> {
    const [session] = await db
      .insert(studySessions)
      .values(insertSession)
      .returning();
    return session;
  }

  async createCardReview(insertReview: InsertCardReview): Promise<CardReview> {
    const [review] = await db
      .insert(cardReviews)
      .values(insertReview)
      .returning();
    return review;
  }

  async getUserStats(userId: number): Promise<StudyStats> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const userSessions = await db.select().from(studySessions)
      .where(eq(studySessions.userId, userId));
    
    const todaySessions = userSessions.filter(session => 
      session.createdAt && new Date(session.createdAt) >= today
    );
    
    const cardsToday = todaySessions.reduce((sum, session) => sum + session.cardsStudied, 0);
    
    const recentSessions = userSessions.slice(-20);
    const accuracy = recentSessions.length > 0 
      ? recentSessions.reduce((sum, session) => sum + session.accuracy, 0) / recentSessions.length
      : 0;
    
    const userDecks = await db.select().from(decks).where(eq(decks.userId, userId));
    const totalDecks = userDecks.length;
    
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    const streak = user?.streak || 0;

    // Calculate weekly performance
    const weeklyPerformance = [];
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
      
      const daySessions = userSessions.filter(session => 
        session.createdAt && 
        new Date(session.createdAt) >= date && 
        new Date(session.createdAt) <= endDate
      );
      
      const dayAccuracy = daySessions.length > 0 
        ? daySessions.reduce((sum, session) => sum + session.accuracy, 0) / daySessions.length
        : 0;
      
      weeklyPerformance.push({
        day: days[date.getDay()],
        accuracy: Math.round(dayAccuracy),
      });
    }

    return {
      cardsToday,
      accuracy: Math.round(accuracy),
      totalDecks,
      streak,
      weeklyPerformance,
    };
  }

  async updateCardProgress(cardId: number, quality: number): Promise<Card | undefined> {
    const [card] = await db.select().from(cards).where(eq(cards.id, cardId));
    if (!card) return undefined;

    // Spaced repetition algorithm (SM-2)
    let { repetitions, easeFactor, interval } = card;
    repetitions = repetitions || 0;
    easeFactor = easeFactor || 2.5;
    interval = interval || 1;
    
    if (quality >= 3) {
      if (repetitions === 0) {
        interval = 1;
      } else if (repetitions === 1) {
        interval = 6;
      } else {
        interval = Math.round(interval * easeFactor);
      }
      repetitions++;
    } else {
      repetitions = 0;
      interval = 1;
    }

    easeFactor = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
    if (easeFactor < 1.3) easeFactor = 1.3;

    const nextReview = new Date();
    nextReview.setDate(nextReview.getDate() + interval);

    const [updatedCard] = await db
      .update(cards)
      .set({
        repetitions,
        easeFactor,
        interval,
        nextReview,
        difficulty: quality < 3 ? Math.min((card.difficulty || 0) + 1, 4) : Math.max((card.difficulty || 0) - 1, 0),
      })
      .where(eq(cards.id, cardId))
      .returning();

    return updatedCard;
  }
}

export const storage = new DatabaseStorage();
