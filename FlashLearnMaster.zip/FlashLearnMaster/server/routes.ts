import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDeckSchema, insertCardSchema, insertStudySessionSchema, insertCardReviewSchema } from "@shared/schema";
import { generateFlashcardsFromText, transcribeAudio } from "./openai";
import multer from "multer";
import fs from "fs";
import path from "path";

const upload = multer({ dest: 'uploads/' });

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/user/:id", async (req, res) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  app.get("/api/users/stats/:userId", async (req, res) => {
    try {
      const stats = await storage.getUserStats(parseInt(req.params.userId));
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user stats" });
    }
  });

  // Deck routes
  app.get("/api/decks/:userId", async (req, res) => {
    try {
      const decks = await storage.getUserDecks(parseInt(req.params.userId));
      res.json(decks);
    } catch (error) {
      res.status(500).json({ message: "Failed to get decks" });
    }
  });

  app.post("/api/decks", async (req, res) => {
    try {
      const deckData = insertDeckSchema.parse(req.body);
      const deck = await storage.createDeck(deckData);
      res.status(201).json(deck);
    } catch (error) {
      res.status(400).json({ message: "Invalid deck data" });
    }
  });

  app.put("/api/decks/:id", async (req, res) => {
    try {
      const deck = await storage.updateDeck(parseInt(req.params.id), req.body);
      if (!deck) {
        return res.status(404).json({ message: "Deck not found" });
      }
      res.json(deck);
    } catch (error) {
      res.status(500).json({ message: "Failed to update deck" });
    }
  });

  app.delete("/api/decks/:id", async (req, res) => {
    try {
      const success = await storage.deleteDeck(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ message: "Deck not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete deck" });
    }
  });

  // Card routes
  app.get("/api/cards/deck/:deckId", async (req, res) => {
    try {
      const cards = await storage.getDeckCards(parseInt(req.params.deckId));
      res.json(cards);
    } catch (error) {
      res.status(500).json({ message: "Failed to get cards" });
    }
  });

  app.get("/api/cards/due/:deckId", async (req, res) => {
    try {
      const cards = await storage.getDueCards(parseInt(req.params.deckId));
      res.json(cards);
    } catch (error) {
      res.status(500).json({ message: "Failed to get due cards" });
    }
  });

  app.post("/api/cards", async (req, res) => {
    try {
      const cardData = insertCardSchema.parse(req.body);
      const card = await storage.createCard(cardData);
      res.status(201).json(card);
    } catch (error) {
      res.status(400).json({ message: "Invalid card data" });
    }
  });

  app.put("/api/cards/:id", async (req, res) => {
    try {
      const card = await storage.updateCard(parseInt(req.params.id), req.body);
      if (!card) {
        return res.status(404).json({ message: "Card not found" });
      }
      res.json(card);
    } catch (error) {
      res.status(500).json({ message: "Failed to update card" });
    }
  });

  app.delete("/api/cards/:id", async (req, res) => {
    try {
      const success = await storage.deleteCard(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ message: "Card not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete card" });
    }
  });

  // Study session routes
  app.post("/api/study-sessions", async (req, res) => {
    try {
      const sessionData = insertStudySessionSchema.parse(req.body);
      const session = await storage.createStudySession(sessionData);
      res.status(201).json(session);
    } catch (error) {
      res.status(400).json({ message: "Invalid session data" });
    }
  });

  app.post("/api/card-reviews", async (req, res) => {
    try {
      const reviewData = insertCardReviewSchema.parse(req.body);
      const review = await storage.createCardReview(reviewData);
      
      // Update card progress using spaced repetition
      await storage.updateCardProgress(reviewData.cardId, reviewData.quality);
      
      res.status(201).json(review);
    } catch (error) {
      res.status(400).json({ message: "Invalid review data" });
    }
  });

  // AI routes
  app.post("/api/ai/generate-flashcards", async (req, res) => {
    try {
      const { text, deckTitle } = req.body;
      if (!text) {
        return res.status(400).json({ message: "Text is required" });
      }

      const flashcards = await generateFlashcardsFromText(text, deckTitle);
      res.json(flashcards);
    } catch (error) {
      console.error("Failed to generate flashcards:", error);
      res.status(500).json({ message: "Failed to generate flashcards" });
    }
  });

  app.post("/api/ai/transcribe", upload.single('audio'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Audio file is required" });
      }

      const transcription = await transcribeAudio(req.file.path);
      
      // Clean up uploaded file
      fs.unlinkSync(req.file.path);
      
      res.json(transcription);
    } catch (error) {
      console.error("Failed to transcribe audio:", error);
      // Clean up uploaded file on error
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch {}
      }
      res.status(500).json({ message: "Failed to transcribe audio" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
