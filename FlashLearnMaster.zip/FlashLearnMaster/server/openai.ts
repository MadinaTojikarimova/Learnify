import OpenAI from "openai";
import fs from "fs";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface GeneratedFlashcard {
  front: string;
  back: string;
  explanation?: string;
}

export interface FlashcardGenerationResult {
  flashcards: GeneratedFlashcard[];
  deckTitle: string;
  totalGenerated: number;
}

export interface TranscriptionResult {
  text: string;
  duration?: number;
}

export async function generateFlashcardsFromText(
  text: string, 
  deckTitle?: string
): Promise<GeneratedFlashcard[]> {
  try {
    const prompt = `
You are an expert educator creating flashcards for effective learning. Based on the following text content, generate high-quality flashcards that focus on key concepts, important facts, and essential knowledge.

Guidelines:
- Create clear, concise questions for the front of each card
- Provide accurate, complete answers for the back of each card
- Focus on the most important concepts and facts
- Vary question types (definitions, explanations, comparisons, applications)
- Ensure questions test understanding, not just memorization
- Generate between 8-15 flashcards depending on content length and complexity
- Use simple, clear language
- Avoid overly complex or ambiguous questions

Text content:
${text}

Please respond with a JSON object containing an array of flashcards. Each flashcard should have "front" and "back" properties.

Format your response as JSON only:
{
  "flashcards": [
    {
      "front": "Question or prompt for the front of the card",
      "back": "Answer or explanation for the back of the card"
    }
  ]
}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert educator creating high-quality flashcards for effective learning. Always respond with valid JSON containing an array of flashcards."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 2000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"flashcards": []}');
    
    if (!result.flashcards || !Array.isArray(result.flashcards)) {
      throw new Error("Invalid response format from OpenAI");
    }

    // Validate and clean the flashcards
    const validFlashcards = result.flashcards
      .filter((card: any) => card.front && card.back && typeof card.front === 'string' && typeof card.back === 'string')
      .map((card: any) => ({
        front: card.front.trim(),
        back: card.back.trim(),
        explanation: card.explanation?.trim() || undefined
      }));

    if (validFlashcards.length === 0) {
      throw new Error("No valid flashcards could be generated from the provided text");
    }

    return validFlashcards;

  } catch (error) {
    console.error("Error generating flashcards:", error);
    
    if (error instanceof Error) {
      if (error.message.includes("API key")) {
        throw new Error("OpenAI API key is invalid or missing. Please check your configuration.");
      }
      if (error.message.includes("quota")) {
        throw new Error("OpenAI API quota exceeded. Please check your usage limits.");
      }
      if (error.message.includes("rate limit")) {
        throw new Error("Rate limit exceeded. Please wait a moment and try again.");
      }
      throw new Error(`Failed to generate flashcards: ${error.message}`);
    }
    
    throw new Error("An unexpected error occurred while generating flashcards. Please try again.");
  }
}

export async function transcribeAudio(audioFilePath: string): Promise<TranscriptionResult> {
  try {
    // Verify the file exists
    if (!fs.existsSync(audioFilePath)) {
      throw new Error("Audio file not found");
    }

    // Get file stats for validation
    const stats = fs.statSync(audioFilePath);
    const fileSizeInMB = stats.size / (1024 * 1024);
    
    // OpenAI Whisper has a 25MB file size limit
    if (fileSizeInMB > 25) {
      throw new Error("Audio file is too large. Maximum size is 25MB.");
    }

    const audioReadStream = fs.createReadStream(audioFilePath);

    const transcription = await openai.audio.transcriptions.create({
      file: audioReadStream,
      model: "whisper-1",
      language: "en", // Can be auto-detected by omitting this
      response_format: "verbose_json", // Get additional metadata
      temperature: 0.2, // Lower temperature for more consistent transcription
    });

    // Clean up the transcribed text
    const cleanedText = transcription.text
      .trim()
      .replace(/\s+/g, ' ') // Replace multiple spaces with single space
      .replace(/[^\w\s.,!?;:()\-'"]/g, ''); // Remove special characters except basic punctuation

    if (!cleanedText || cleanedText.length < 10) {
      throw new Error("The audio file appears to contain insufficient speech content for transcription.");
    }

    return {
      text: cleanedText,
      duration: transcription.duration || 0,
    };

  } catch (error) {
    console.error("Error transcribing audio:", error);
    
    if (error instanceof Error) {
      if (error.message.includes("API key")) {
        throw new Error("OpenAI API key is invalid or missing. Please check your configuration.");
      }
      if (error.message.includes("quota")) {
        throw new Error("OpenAI API quota exceeded. Please check your usage limits.");
      }
      if (error.message.includes("rate limit")) {
        throw new Error("Rate limit exceeded. Please wait a moment and try again.");
      }
      if (error.message.includes("file format")) {
        throw new Error("Unsupported audio format. Please use MP3, WAV, M4A, or other common audio formats.");
      }
      if (error.message.includes("too large")) {
        throw new Error("Audio file is too large. Maximum size is 25MB.");
      }
      if (error.message.includes("insufficient speech")) {
        throw new Error("The audio file appears to contain insufficient speech content for transcription.");
      }
      if (error.message.includes("not found")) {
        throw new Error("Audio file could not be found or accessed.");
      }
      
      throw new Error(`Failed to transcribe audio: ${error.message}`);
    }
    
    throw new Error("An unexpected error occurred while transcribing the audio. Please try again with a different file.");
  }
}

export async function enhanceFlashcardContent(
  flashcards: GeneratedFlashcard[],
  subject?: string
): Promise<GeneratedFlashcard[]> {
  try {
    const prompt = `
You are an expert educator. Please review and enhance the following flashcards to improve their educational value. 

Guidelines:
- Ensure questions are clear and unambiguous
- Make answers comprehensive but concise
- Add context or explanations where helpful
- Maintain the same number of flashcards
- Keep the core concepts intact
- Improve clarity and learning effectiveness

${subject ? `Subject area: ${subject}` : ''}

Original flashcards:
${JSON.stringify(flashcards, null, 2)}

Please respond with the enhanced flashcards in the same JSON format:
{
  "flashcards": [
    {
      "front": "Enhanced question or prompt",
      "back": "Enhanced answer or explanation"
    }
  ]
}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system", 
          content: "You are an expert educator enhancing flashcards for better learning outcomes. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
      max_tokens: 2000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"flashcards": []}');
    
    if (!result.flashcards || !Array.isArray(result.flashcards)) {
      // Return original flashcards if enhancement fails
      return flashcards;
    }

    return result.flashcards.map((card: any) => ({
      front: card.front?.trim() || '',
      back: card.back?.trim() || '',
      explanation: card.explanation?.trim() || undefined
    }));

  } catch (error) {
    console.error("Error enhancing flashcards:", error);
    // Return original flashcards if enhancement fails
    return flashcards;
  }
}

export async function generateQuizQuestions(
  flashcards: GeneratedFlashcard[],
  numberOfQuestions: number = 5
): Promise<any[]> {
  try {
    const prompt = `
Based on the following flashcards, generate ${numberOfQuestions} multiple choice quiz questions. Each question should have 4 options with only one correct answer.

Flashcards:
${JSON.stringify(flashcards, null, 2)}

Format your response as JSON:
{
  "questions": [
    {
      "question": "Question text",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0,
      "explanation": "Brief explanation of why this is correct"
    }
  ]
}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert educator creating multiple choice quiz questions. Always respond with valid JSON."
        },
        {
          role: "user", 
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.5,
      max_tokens: 1500,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"questions": []}');
    return result.questions || [];

  } catch (error) {
    console.error("Error generating quiz questions:", error);
    throw new Error("Failed to generate quiz questions");
  }
}
